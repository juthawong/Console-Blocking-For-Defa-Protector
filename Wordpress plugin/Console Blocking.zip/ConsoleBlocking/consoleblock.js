window.console.log = function(){

    window.console.log = function() {
  	document.innerHTML = "";
window.location.href = "/403";
    }
}